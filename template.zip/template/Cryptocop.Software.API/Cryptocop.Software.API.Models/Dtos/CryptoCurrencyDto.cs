namespace Cryptocop.Software.API.Models.Dtos
{
    public class CryptoCurrencyDto
    {
        
    }
}