namespace Cryptocop.Software.API.Models.InputModels
{
    public class LoginInputModel
    {
        
    }
}